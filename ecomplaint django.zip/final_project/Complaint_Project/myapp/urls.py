from django.urls import path
from django.conf.urls import url
from . import views

urlpatterns = [
    path("home/", views.home, name="home"),
    path("homepage/", views.homepage, name="homepage"),
    path("email/", views.email, name="email"),
    path("logout/", views.logout, name="logout"),
    path("user_login/", views.user_login, name="user_login"),
    path("signup/", views.signup, name="signup"),
    path("login/", views.login, name="login"),
    path("citizenservices/", views.citizenservices, name="citizenservices"),
    url(r'^MVTheft/(?P<id>\d+)/$', views.MVTheft, name="MVTheft"),
    url(r'^Theft/(?P<id>\d+)/$', views.theft, name="theft"),
    url(r'^Eco_Cyber/(?P<id>\d+)/$', views.eco_cyber, name="eco_cyber"),
    path("admin/", views.admin, name="admin"),
    url(r'^Missing_Children/(?P<id>\d+)/$', views.missingchildren, name="missingchildren"),
    url(r'^Missing_Person/(?P<id>\d+)/$', views.missingperson, name="missingperson"),
    url(r'^Road_Accident/(?P<id>\d+)/$', views.roadaccident, name="road_accident"),
    url(r'^Rape/(?P<id>\d+)/$', views.rape, name="rape"),
    url(r'^Murder/(?P<id>\d+)/$', views.murder, name="murder"),
    url(r'^Dowry/(?P<id>\d+)/$', views.dowry, name="dowry"),
    url(r'^Domestic_Violence/(?P<id>\d+)/$', views.domesticviolence, name="domestic_violence"),
    url(r'^LostnFound/(?P<id>\d+)/$', views.lostandfound, name="lostnfound"),
    url(r'^Eve_Teasing/(?P<id>\d+)/$', views.eveteasing, name="eve_teasing"),
    url(r'^preview/(?P<id>\d+)/$', views.preview_comp, name="pre_view"),
]
