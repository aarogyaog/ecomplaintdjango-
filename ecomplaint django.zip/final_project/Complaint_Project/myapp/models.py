from django.db import models


class CitizeN(models.Model):
    name = models.CharField(max_length=100, blank=False, default='a', null=True)
    password = models.CharField(max_length=20, blank=False, default='', null=True)
    email = models.EmailField(max_length=50, blank=False, default='a@gmail.com', null=True)
    mobile = models.IntegerField(blank=False, default=123, null=True)
    address = models.TextField(blank=False, default='jaipur', null=True)


class MVthefT(models.Model):
    vehiclno = models.CharField(max_length=20, help_text="Enter the Number of Your Vehicle:", null=True)
    vtype = models.CharField(max_length=50, help_text="Enter the type of your Vehicle:", null=True)
    vcolor = models.CharField(max_length=50, help_text="Enter the color of your vehicle:", null=True)
    vmodel = models.CharField(max_length=50, help_text="Enter the Model Number Of your Vehicle:", null=True)
    area = models.TextField(help_text="Enter the Location of Vehicle from where it is stolen:", null=True)
    desc = models.TextField(help_text="Enter Description:", null=True)
    date = models.DateField(help_text="Enter Date:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.CASCADE, null=True)


class ThefT(models.Model):
    crime = models.CharField(default="Theft", max_length=50)
    location = models.TextField(help_text="Enter Location:", null=True)
    desc = models.TextField(help_text="Enter description:", null=True)
    date = models.DateField(help_text="Enter Date:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class lostnfounD(models.Model):
    article = models.CharField(max_length=100, help_text="Enter the article you have lost:", null=True)
    location = models.TextField(help_text="Enter the place where it was last seen:", null=True)
    desc = models.TextField(help_text="Enter the description of the article:", null=True)
    date = models.DateField(help_text="Enter the Date on which you have lost it:", null=True)
    time = models.TimeField(help_text="Enter the time when it was last seen:", null=True)
    pic = models.ImageField(help_text="Attach the photo of the lost article:", upload_to='media/', null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class eco_cybeR(models.Model):
    crime = models.CharField(max_length=100, help_text="Enter Crime:", null=True)
    desc = models.TextField(help_text="Enter Description of Crime:", null=True)
    date = models.DateField(help_text="Enter Date:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.CASCADE, null=True)


class missing_childreN(models.Model):
    name = models.CharField(max_length=100, help_text="Enter the name of the child:", null=True)
    height = models.DecimalField(decimal_places=2, max_digits=5, help_text="Enter the height of the Child:", null=True)
    gender = models.CharField(max_length=25, help_text="Enter the Gender of the child:", null=True)
    age = models.IntegerField(help_text="Enter the age of the child:", null=True)
    weight = models.DecimalField(max_digits=5, decimal_places=2, help_text="Enter the weight of the child:", null=True)
    desc = models.TextField(help_text="Enter Description of Missing Child:", null=True)
    location = models.CharField(max_length=100, help_text="Enter the location where the child was last seen:",
                                null=True)
    pic = models.ImageField(help_text="Attach the pucture of the child:", upload_to='media/', null=True)
    date = models.DateField(help_text="Enter the date when the child was last seen", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class missing_persoN(models.Model):
    name = models.CharField(max_length=100, help_text="Enter the name of the missing person:", null=True)
    height = models.DecimalField(max_digits=5, decimal_places=2, help_text="Enter the height of the missing person:",
                                 null=True)
    gender = models.CharField(max_length=15, help_text="Enter the Gender of the missing person:", null=True)
    age = models.IntegerField(help_text="Enter the age of the missing person:", null=True)
    weight = models.DecimalField(max_digits=5, decimal_places=2, help_text="Enter the weight of the missing person:",
                                 null=True)
    desc = models.TextField(help_text="Enter Description of Missing missing person:", null=True)
    location = models.CharField(max_length=100, help_text="Enter the location where the person was last seen:",
                                null=True)
    pic = models.ImageField(help_text="Attach the pucture of the missing person:", upload_to='media/', null=True)
    date = models.DateField(help_text="Enter the date when the person was last seen:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class DomesticViolencE(models.Model):
    vname = models.CharField(max_length=100, help_text="Enter the victim's Name:", null=True)
    cdesc = models.TextField(help_text="Enter the Description of the Crime:", null=True)
    cname = models.CharField(max_length=100, help_text="Enter the criminal's name:", null=True)
    location = models.TextField(help_text="Enter the location of crime:", null=True)
    date = models.DateField(help_text="Enter the date of the crime:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class DowrY(models.Model):
    cname = models.CharField(max_length=100, help_text="Enter the criminal's name:", null=True)
    address = models.TextField(help_text="Enter the location of crime:", null=True)
    date = models.DateField(help_text="Enter the date of the crime:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class EveTeasinG(models.Model):
    location = models.TextField(help_text="Enter the location of crime:", null=True)
    date = models.DateField(help_text="Enter the Date:", null=True)
    num = models.IntegerField(help_text="Enter Number of Suspects:", null=True)
    sname = models.CharField(max_length=100, help_text="Enter the suspect's name:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class MurdeR(models.Model):
    location = models.TextField(help_text="Enter the location of Murder:", null=True)
    vname = models.CharField(max_length=100, help_text="Enter the victim's name:", null=True)
    sname = models.CharField(max_length=100, help_text="Enter the suspect's  name:", null=True)
    date = models.DateField(help_text="Enter date:", null=True)
    time = models.TimeField(help_text="Enter the time of crime:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class RapE(models.Model):
    vname = models.CharField(max_length=100, help_text="Enter the victim's name:", null=True)
    sname = models.CharField(max_length=100, help_text="Enter the suspect's  name:", null=True)
    location = models.TextField(help_text="Enter the location of crime:", null=True)
    date = models.DateField(help_text="Enter date:", null=True)
    time = models.TimeField(help_text="Enter the time of crime:", null=True)

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)


class road_accidenT(models.Model):
    vname = models.CharField(max_length=100, help_text="Enter the victim's name:", null=True)
    sname = models.CharField(max_length=100, help_text="Enter the suspect's  name:", null=True)
    location = models.TextField(help_text="Enter the location of crime:", null=True)
    date = models.DateField(help_text="Enter date:", null=True)
    time = models.TimeField(help_text="Enter the time of crime:", null=True)
    vehiclno = models.CharField(help_text="Enter the vehicle number:", null=True, max_length=10)
    vmodel = models.CharField(max_length=20, help_text="Enter the model of the vehicle:", null=True)
    vcolor = models.CharField(max_length=15, help_text="Enter the color of the vehicle:", null=True)
    vtype = models.CharField(max_length=20, help_text="Enter the type of the vehicle:", null=True)
    desc = models.TextField(help_text="Enter Description about the accident:")

    citizen = models.ForeignKey('CitizeN', on_delete=models.SET_NULL, null=True)
