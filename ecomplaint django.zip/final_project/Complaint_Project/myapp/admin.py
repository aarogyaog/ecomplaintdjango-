from django.contrib import admin
from . models import *

admin.site.register(CitizeN)
admin.site.register(MVthefT)
admin.site.register(ThefT)
admin.site.register(missing_persoN)
admin.site.register(missing_childreN)
admin.site.register(DomesticViolencE)
admin.site.register(DowrY)
admin.site.register(EveTeasinG)
admin.site.register(road_accidenT)
admin.site.register(MurdeR)
admin.site.register(eco_cybeR)
admin.site.register(lostnfounD)
admin.site.register(RapE)