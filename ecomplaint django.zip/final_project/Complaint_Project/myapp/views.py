from django.shortcuts import render, HttpResponse, get_object_or_404, redirect
from .models import *
from django.contrib import auth



def home(request):
    return render(request, "home.html")


def homepage(request):
    return render(request, "homepage.html")


def admin(request):
    return render(request, "admin")


def preview_comp(request, id=None):
    a = get_object_or_404(CitizeN, id=id)
    m = MVthefT.objects.all().filter(citizen=a)
    t = ThefT.objects.all().filter(citizen=a)
    l = lostnfounD.objects.all().filter(citizen=a)
    ec = eco_cybeR.objects.all().filter(citizen=a)
    mc = missing_childreN.objects.all().filter(citizen=a)
    mp = missing_persoN.objects.all().filter(citizen=a)
    dv = DomesticViolencE.objects.all().filter(citizen=a)
    d = DowrY.objects.all().filter(citizen=a)
    et = EveTeasinG.objects.all().filter(citizen=a)
    mr = MurdeR.objects.all().filter(citizen=a)
    r = RapE.objects.all().filter(citizen=a)
    ra = road_accidenT.objects.all().filter(citizen=a)
    return render(request, "preview_comp.html",
                  {'a': a, 'm': m, 't': t, 'l': l, 'ec': ec, 'mc': mc, 'mp': mp, 'dv': dv, 'd': d, 'et': et, 'mr': mr,
                   'r': r, 'ra': ra})


def email(request):
    return render(request, "email.html")


def user_login(request):
    return render(request, "user_login.html")


def citizenservices(request):
    return render(request, "citizenservices.html")


def MVTheft(request, id=None):
    if request.method == "GET":
        return render(request, "MVTheft.html")
    if request.method == "POST":
        email = request.POST.get('email')
        vehiclno = request.POST.get('vehiclno')
        vtype = request.POST.get('vtype')
        vcolor = request.POST.get('vcolor')
        vmodel = request.POST.get('vmodel')
        area = request.POST.get('area')
        desc = request.POST.get('desc')
        date = request.POST.get('date')
        mvt = MVthefT()
        mvt.citizen = get_object_or_404(CitizeN, email=email)
        print(mvt.citizen)
        mvt.vehiclno = vehiclno
        mvt.vtype = vtype
        mvt.vcolor = vcolor
        mvt.vmodel = vmodel
        mvt.area = area
        mvt.desc = desc
        mvt.date = date
        mvt.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def roadaccident(request, id=None):
    if request.method == 'GET':
        return render(request, "road_accident.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        vname = request.POST.get('vname')
        sname = request.POST.get('sname')
        desc = request.POST.get('desc')
        location = request.POST.get('location')
        date = request.POST.get('date')
        time = request.POST.get('time')
        vehiclno = request.POST.get('vehiclno')
        vmodel = request.POST.get('vmodel')
        vcolor = request.POST.get('vcolor')
        vtype = request.POST.get('vtype')

        ra = road_accidenT()
        ra.citizen = get_object_or_404(CitizeN, email=email)
        print(ra.citizen)
        ra.vname = vname
        ra.desc = desc
        ra.sname = sname
        ra.location = location
        ra.date = date
        ra.time = time
        ra.vehiclno = vehiclno
        ra.vtype = vtype
        ra.vcolor = vcolor
        ra.vmodel = vmodel
        ra.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def rape(request, id=None):
    if request.method == 'GET':
        return render(request, "rape.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        vname = request.POST.get('vname')
        time = request.POST.get('time')
        sname = request.POST.get('sname')
        location = request.POST.get('location')
        date = request.POST.get('date')

        rp = RapE()
        rp.citizen = get_object_or_404(CitizeN, email=email)
        print(rp.citizen)
        rp.vname = vname
        rp.time = time
        rp.sname = sname
        rp.location = location
        rp.date = date
        rp.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def dowry(request, id=None):
    if request.method == 'GET':
        return render(request, "dowry.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        cname = request.POST.get('cname')
        address = request.POST.get('address')
        date = request.POST.get('date')

        dow = DowrY()
        dow.citizen = get_object_or_404(CitizeN, email=email)
        print(dow.citizen)
        dow.cname = cname
        dow.address = address
        dow.date = date
        dow.save()
        return render(request, "dowry.html", {'z': 1, 'e': id})


def domesticviolence(request, id=None):
    if request.method == 'GET':
        return render(request, "domestic_violence.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        vname = request.POST.get('vname')
        cdesc = request.POST.get('cdesc')
        cname = request.POST.get('cname')
        location = request.POST.get('location')
        date = request.POST.get('date')

        dv = DomesticViolencE()
        dv.citizen = get_object_or_404(CitizeN, email=email)
        print(dv.citizen)
        dv.vname = vname
        dv.cdesc = cdesc
        dv.cname = cname
        dv.location = location
        dv.date = date
        dv.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def murder(request, id=None):
    if request.method == 'GET':
        return render(request, "murder.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        vname = request.POST.get('vname')
        time = request.POST.get('time')
        sname = request.POST.get('sname')
        location = request.POST.get('location')
        date = request.POST.get('date')

        md = MurdeR()
        md.citizen = get_object_or_404(CitizeN, email=email)
        print(md.citizen)
        md.vname = vname
        md.time = time
        md.sname = sname
        md.location = location
        md.date = date
        md.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def eveteasing(request, id=None):
    if request.method == 'GET':
    if request.method == 'GET':
        return render(request, "eve_teasing.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        num = request.POST.get('num')
        sname = request.POST.get('sname')
        location = request.POST.get('location')
        date = request.POST.get('date')

        et = EveTeasinG()
        et.citizen = get_object_or_404(CitizeN, email=email)
        print(et.citizen)
        et.sname = sname
        et.num = num
        et.location = location
        et.date = date
        et.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def lostandfound(request, id=None):
    if request.method == 'GET':
        return render(request, "lostnfound.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        article = request.POST.get('article')
        time = request.POST.get('time')
        location = request.POST.get('location')
        desc = request.POST.get('desc')
        date = request.POST.get('date')
        if 'pic' in request.FILES:
            pic = request.FILES['pic']
        else:
            pic = None

        lnf = lostnfounD()
        lnf.citizen = get_object_or_404(CitizeN, email=email)
        print(lnf.citizen)
        lnf.article = article
        lnf.gender = time
        lnf.location = location
        lnf.desc = desc
        lnf.date = date
        lnf.pic = pic
        lnf.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def missingchildren(request, id=None):
    if request.method == 'GET':
        return render(request, "missing_children.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        name = request.POST.get('name')
        height = request.POST.get('height')
        weight = request.POST.get('weight')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        location = request.POST.get('location')
        desc = request.POST.get('desc')
        date = request.POST.get('date')
        if 'pic' in request.FILES:
            pic = request.FILES['pic']
        else:
            pic = None

        mch = missing_childreN()
        mch.citizen = get_object_or_404(CitizeN, email=email)
        print(mch.citizen)
        mch.name = name
        mch.age = age
        mch.height = height
        mch.weight = weight
        mch.gender = gender
        mch.location = location
        mch.desc = desc
        mch.date = date
        mch.pic = pic
        mch.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def missingperson(request, id=None):
    if request.method == 'GET':
        return render(request, "missing_person.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        name = request.POST.get('name')
        height = request.POST.get('height')
        weight = request.POST.get('weight')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        location = request.POST.get('location')
        desc = request.POST.get('desc')
        date = request.POST.get('date')
        if 'pic' in request.FILES:
            pic = request.FILES['pic']
        else:
            pic = None

        mch = missing_persoN()
        mch.citizen = get_object_or_404(CitizeN, email=email)
        print(mch.citizen)
        mch.name = name
        mch.age = age
        mch.height = height
        mch.weight = weight
        mch.gender = gender
        mch.location = location
        mch.desc = desc
        mch.date = date
        mch.pic = pic
        mch.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def theft(request, id=None):
    if request.method == 'GET':
        return render(request, "theft.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        location = request.POST.get('location')
        desc = request.POST.get('desc')
        date = request.POST.get('date')

        th = ThefT()
        th.citizen = get_object_or_404(CitizeN, email=email)
        print(th.citizen)
        th.location = location
        th.desc = desc
        th.date = date
        th.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def eco_cyber(request, id=None):
    if request.method == 'GET':
        return render(request, "eco_cyber.html")
    if request.method == 'POST':
        email = request.POST.get('email')
        crime = request.POST.get('crime')
        desc = request.POST.get('desc')
        date = request.POST.get('date')

        eco = eco_cybeR()
        eco.citizen = get_object_or_404(CitizeN, email=email)
        print(eco.citizen)
        eco.crime = crime
        eco.desc = desc
        eco.date = date
        eco.save()
        return render(request, "citizenservices.html", {'z': 1, 'e': id})


def login(request):
    if request.method == 'GET':
        return render(request, "login.html")
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')

        request.session['email'] = email
        request.session['password'] = password

        try:
            user = CitizeN.objects.get(email=email, password=password)
            k = get_object_or_404(CitizeN, email=email)
            return render(request, "citizenservices.html", {'e': k.id})
        except CitizeN.DoesNotExist:
            return render(request, "login.html", {"error": True, "error_msg": "User Does Not Exist"})


success = False


def signup(request):
    if request.method == "GET":
        return render(request, "signup.html")
    if request.method == "POST":
        cobj = CitizeN()
        cobj.name = request.POST.get('name')
        cobj.mobile = request.POST.get('mobile')
        cobj.address = request.POST.get('address')
        cobj.email = request.POST.get('email')
        cobj.password = request.POST.get('password')
        cobj.save()  # to save the record into citizen table
        success = True
        return redirect('/login')


def logout(request):
    auth.logout(request)
    return redirect('/homepage')
